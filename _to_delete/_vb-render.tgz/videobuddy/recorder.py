"""ffmpeg: HLS -> Datei (siehe README-Architekturdiagramm).

Bewusst ohne In-Memory-Prozess-Handle: der Scheduler-Loop prüft Liveness nur
über die in jobs.json gespeicherte PID (os.kill(pid, 0)). Dadurch übersteht
eine laufende Aufnahme einen Neustart des Scheduler-Prozesses - ffmpeg läuft
dank start_new_session als eigene Session weiter, auch wenn entrypoint.sh dem
Scheduler-Prozess SIGTERM schickt.

Ausgabe-Container ist .ts (MPEG-TS), nicht .mkv oder .mp4: "-c copy" von HLS
(AAC in ADTS) funktioniert damit ohne den sonst nötigen
aac_adtstoasc-Bitstream-Filter - genau wie bei .mkv. Der Unterschied zu .mkv:
.ts braucht keinen abschließenden Trailer/Index, um gültig zu sein. Wird der
ffmpeg-Prozess mitten in der Aufnahme hart gekillt (z. B. weil der
Docker-Container während einer laufenden Aufnahme neu gestartet wird - das
killt trotz start_new_session den ganzen Prozessbaum im Container), bleibt
eine .ts-Datei bis zum Abbruchpunkt gültig und abspielbar. Bei .mkv/.mp4 kann
ein solcher harter Abbruch dagegen fast die komplette Aufnahme unbrauchbar
machen, weil ohne sauberen Abschluss kein gültiger Index geschrieben wird.
"""

from __future__ import annotations

import os
import re
import subprocess
from datetime import datetime, timezone


def _sanitize(text: str) -> str:
    text = re.sub(r"[^\w\-. ]", "", text, flags=re.UNICODE)
    text = text.strip().replace(" ", "_")
    return text[:80] or "aufnahme"


def build_output_path(recording_dir: str, title: str, record_start: datetime) -> str:
    """Dateiname [yyyyMMdd]_[Sendungsname].ts. Kollidiert das mit einer
    bereits vorhandenen Datei (z. B. zwei Ausstrahlungen desselben Titels am
    selben Tag), wird die Uhrzeit angehängt, damit keine Aufnahme eine
    andere stillschweigend überschreibt (ffmpeg läuft mit "-y")."""
    os.makedirs(recording_dir, exist_ok=True)
    base = f"{record_start.strftime('%Y%m%d')}_{_sanitize(title)}"
    output_path = os.path.join(recording_dir, base + ".ts")
    if os.path.exists(output_path):
        base = f"{base}_{record_start.strftime('%H%M')}"
        output_path = os.path.join(recording_dir, base + ".ts")
    return output_path


def start_recording(stream_url: str, output_path: str, record_end: datetime) -> int:
    """Startet ffmpeg mit "-t <Sekunden>" (Endzeit ist beim Start schon
    bekannt, kein manuelles Stop-Polling nötig). Gibt die PID zurück."""
    duration_seconds = max(
        1, int((record_end - datetime.now(timezone.utc)).total_seconds())
    )
    log_path = output_path + ".log"
    cmd = [
        "ffmpeg",
        "-y",
        "-loglevel",
        "warning",
        "-i",
        stream_url,
        "-t",
        str(duration_seconds),
        "-c",
        "copy",
        output_path,
    ]
    with open(log_path, "wb") as log_fh:
        process = subprocess.Popen(
            cmd,
            stdout=log_fh,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    return process.pid


def is_finished(pid: int | None) -> bool:
    """Liveness-Check rein über die PID, kein Popen-Handle nötig."""
    if pid is None:
        return True
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return True
    except PermissionError:
        return False
    return False


def delete_files(output_path: str | None) -> None:
    """Löscht die Aufnahme + das zugehörige ffmpeg-Log, falls vorhanden.
    Wird sowohl vom Scheduler-Loop (Mediathek-Fund) als auch von der
    Weboberfläche (manuelles Löschen) benutzt."""
    if not output_path:
        return
    if os.path.exists(output_path):
        os.remove(output_path)
    log_path = output_path + ".log"
    if os.path.exists(log_path):
        os.remove(log_path)
